package org.vcts.automation.core;

/**
 * @author Somnath on 02.01.2023
 */
public final class Constants {

    public static final int WAIT_TIMEOUT = 10;

}

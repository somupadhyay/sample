package org.vcts.automation;

import org.vcts.automation.consignment.ConsignmentDetail;
import org.vcts.automation.consignment.DownloadConsignments;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class DownloadConsignmentMain {
    private String fileName;

    public DownloadConsignmentMain(String fileName) {
        this.fileName = fileName;
    }

    public void run() {
        List<String> allLines = readFile();
        if (allLines.isEmpty() || allLines.size() < 3) {
            System.err.println("nothing to download");
            System.exit(0);
        }
        String username = getUserName(allLines);
        String password = getPassword(allLines);
        List<String> consigmentIds = getConsigmentId(allLines);
        allLines = null;
        DownloadConsignments dc = new DownloadConsignments(username, password);
        Map<String, List<ConsignmentDetail>> docDB = dc.downloadConsigment(consigmentIds);
        writeToFile(docDB);
    }

    private static List<String> getConsigmentId(List<String> allLines) {
        int i = 0;
        List<String> ids = new ArrayList<>();
        for (String id : allLines) {
            if (i > 1) {
                ids.add(id.trim());
            }
            i++;
        }
        return ids;
    }

    private static String getPassword(List<String> allLines) {
        return allLines.get(1).trim();
    }

    private static String getUserName(List<String> allLines) {
        return allLines.get(0).trim();
    }

    public final List<String> readFile() {
        List<String> allLines = null;
        try {
            allLines = Files.readAllLines(Paths.get(fileName));

            for (String line : allLines) {
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return allLines == null ? Collections.emptyList() : allLines;
    }

    public void writeToFile(Map<String, List<ConsignmentDetail>> docDB) {
        String outFile = fileName + "-" + System.currentTimeMillis() + ".csv";
        List<ConsignmentDetail> consignmentDetailList = new ArrayList<>();
        docDB.forEach((k,v) -> consignmentDetailList.addAll(v));
        String contents = ConsignmentDetail.toCSV(consignmentDetailList);

        System.out.println("\n");
        System.out.println(contents);
        PrintWriter out = null;
        try {

            // write to file
            out = new PrintWriter(new OutputStreamWriter(new FileOutputStream(outFile),"UTF-8"));
            out.write(contents);
        } catch (IOException ex) {
            ex.printStackTrace();
        }finally {
            if( out != null){
                out.close();
            }
        }
    }
}

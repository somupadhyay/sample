package org.vcts.automation.consignment;

import org.apache.commons.lang3.StringUtils;

import java.util.Collection;
import java.util.Objects;

public class ConsignmentDetail {

    private String sn;
    private String documentType;
    private String customPoint;
    private String documentNumber;
    private String documentDate;
    private String goodsNature;
    private String packageOrUnit;
    private String quantity;
    private String totalAmountWithoutVAT;
    private String supplierPANNo;

    private String supplierName;
    private String buyerPANNo;

    private String buyerName;
    private String destinationLocation;

    private String remarks;

    private String vehicleNumber;
    private String driverName;
    private String mobileNo;
    private String departureLocation;
    private String departureDateTime;

    private String consignmentNo;

    public String getSn() {
        return sn;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public String getCustomPoint() {
        return customPoint;
    }

    public void setCustomPoint(String customPoint) {
        this.customPoint = customPoint;
    }

    public String getDocumentNumber() {
        return documentNumber;
    }

    public void setDocumentNumber(String documentNumber) {
        this.documentNumber = documentNumber;
    }

    public String getDocumentDate() {
        return documentDate;
    }

    public void setDocumentDate(String documentDate) {
        this.documentDate = documentDate;
    }

    public String getGoodsNature() {
        return goodsNature;
    }

    public void setGoodsNature(String goodsNature) {
        this.goodsNature = goodsNature;
    }

    public String getPackageOrUnit() {
        return packageOrUnit;
    }

    public void setPackageOrUnit(String packageOrUnit) {
        this.packageOrUnit = packageOrUnit;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getTotalAmountWithoutVAT() {
        return totalAmountWithoutVAT;
    }

    public void setTotalAmountWithoutVAT(String totalAmountWithoutVAT) {
        this.totalAmountWithoutVAT = totalAmountWithoutVAT;
    }

    public String getSupplierPANNo() {
        return supplierPANNo;
    }

    public void setSupplierPANNo(String supplierPANNo) {
        this.supplierPANNo = supplierPANNo;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public String getBuyerPANNo() {
        return buyerPANNo;
    }

    public void setBuyerPANNo(String buyerPANNo) {
        this.buyerPANNo = buyerPANNo;
    }

    public String getBuyerName() {
        return buyerName;
    }

    public void setBuyerName(String buyerName) {
        this.buyerName = buyerName;
    }

    public String getDestinationLocation() {
        return destinationLocation;
    }

    public void setDestinationLocation(String destinationLocation) {
        this.destinationLocation = destinationLocation;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getVehicleNumber() {
        return vehicleNumber;
    }

    public void setVehicleNumber(String vehicleNumber) {
        this.vehicleNumber = vehicleNumber;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getDepartureLocation() {
        return departureLocation;
    }

    public void setDepartureLocation(String departureLocation) {
        this.departureLocation = departureLocation;
    }

    public String getDepartureDateTime() {
        return departureDateTime;
    }

    public void setDepartureDateTime(String departureDateTime) {
        this.departureDateTime = departureDateTime;
    }

    public String getConsignmentNo() {
        return consignmentNo;
    }

    public void setConsignmentNo(String consignmentNo) {
        this.consignmentNo = consignmentNo;
    }

    public void add(String ele, int index){
        switch (index){
            case 1:
                setSn(ele);
                break;
            case 2:
                setDocumentType(ele);
                break;
            case 3:
                setCustomPoint(ele);
                break;
            case 4:
                setDocumentNumber(ele);
                break;
            case 5:
                setDocumentDate(ele);
                break;
            case 6:
                setGoodsNature(ele);
                break;
            case 7:
                setPackageOrUnit(ele);
                break;
            case 8:
                setQuantity(ele);
                break;
            case 9:
                setTotalAmountWithoutVAT(ele);
                break;
            case 10:
                setSupplierPANNo(ele);
                break;
            case 11:
                setSupplierName(ele);
                break;
            case 12:
                setBuyerPANNo(ele);
                break;
            case 13:
                setBuyerName(ele);
                break;
            case 14:
                setDestinationLocation(ele);
                break;
            case 15:
                setRemarks(ele);
                break;
            case 41:
                setVehicleNumber(ele);
                break;
            case 42:
                setDriverName(ele);
                break;
            case 43:
                setMobileNo(ele);
                break;
            case 44:
                setDepartureLocation(ele);
                break;
            case 45:
                System.out.println("do nothing");
                break;
            default:
                break;
        }
    }

    @Override
    public String toString() {
        return "Document{" +
                "sn='" + sn + '\'' +
                ", documentType='" + documentType + '\'' +
                ", customPoint='" + customPoint + '\'' +
                ", documentNumber='" + documentNumber + '\'' +
                ", documentDate='" + documentDate + '\'' +
                ", goodsNature='" + goodsNature + '\'' +
                ", packageOrUnit='" + packageOrUnit + '\'' +
                ", quantity='" + quantity + '\'' +
                ", totalAmountWithoutVAT='" + totalAmountWithoutVAT + '\'' +
                ", supplierPANNo='" + supplierPANNo + '\'' +
                ", supplierName='" + supplierName + '\'' +
                ", buyerPANNo='" + buyerPANNo + '\'' +
                ", buyerName='" + buyerName + '\'' +
                ", destinationLocation='" + destinationLocation + '\'' +
                ", remarks='" + remarks + '\'' +
                ", vehicleNumber='" + vehicleNumber + '\'' +
                ", driverName='" + driverName + '\'' +
                ", mobileNo='" + mobileNo + '\'' +
                ", departureLocation='" + departureLocation + '\'' +
                ", departureDateTime='" + departureDateTime + '\'' +
                ", consignmentNo='" + consignmentNo + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ConsignmentDetail consignmentDetail = (ConsignmentDetail) o;
        return Objects.equals(consignmentNo, consignmentDetail.consignmentNo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(consignmentNo);
    }

    public static String toCSV(Collection<ConsignmentDetail> consignmentDetailList){
        StringBuilder sb = new StringBuilder();
        String[] headers = {
                "S.N.",             "Document Type",  "Custom Point", "Document Number",              "Document Date",
                "Goods Nature",     "Package / Unit", "Quantity",     "Total Amount (without VAT)",   "Supplier PAN No.",
                "Supplier Name",    "Buyer PAN No.",  "Buyer Name",   "Destination location ",        "Remarks",
                "Vehicle Number",   "Driver Name",    "Mobile No.",   "Departure Location",           "Consignment ID"};
        sb.append(StringUtils.join(headers,"|"));
        sb.append("\n");
        if(null == consignmentDetailList || consignmentDetailList.isEmpty()){
            return sb.toString();
        }
        for(ConsignmentDetail doc: consignmentDetailList){
            sb.append(doc.sn).append(" | ").append(doc.documentType).append(" | ").append(doc.customPoint).append(" | ").append(doc.documentNumber).append(" | ").append(doc.documentDate).append(" | ")
              .append(doc.goodsNature).append(" | ").append(doc.packageOrUnit).append(" | ").append(doc.quantity).append(" | ").append(doc.totalAmountWithoutVAT).append(" | ").append(doc.supplierPANNo).append(" | ")
              .append(doc.supplierName).append(" | ").append(doc.buyerPANNo).append(" | ").append(doc.buyerName).append(" | ").append(doc.destinationLocation).append(" | ").append(doc.remarks).append(" | ")
              .append(doc.vehicleNumber).append(" | ").append(doc.driverName).append(" | ").append(doc.mobileNo).append(" | ").append(doc.departureLocation).append(" | ").append(doc.getConsignmentNo());
            sb.append("\n");
        }
        return sb.toString();
    }

    public ConsignmentDetail copy(){
        ConsignmentDetail copy = new ConsignmentDetail();
        copy.sn = this.sn;
        copy.documentType = this.documentType;
        copy.customPoint = this.customPoint;
        copy.documentNumber = this.documentNumber;
        copy.documentDate = this.documentDate;
        copy.goodsNature = this.goodsNature;
        copy.packageOrUnit = this.packageOrUnit;
        copy.quantity = this.quantity;
        copy.totalAmountWithoutVAT = this.totalAmountWithoutVAT;
        copy.supplierPANNo = this.supplierPANNo;
        copy.supplierName = this.supplierName;
        copy.buyerPANNo = this.buyerPANNo;
        copy.buyerName = this.buyerName;
        copy.destinationLocation = this.destinationLocation;
        copy.remarks = this.remarks;
        copy.vehicleNumber = this.vehicleNumber;
        copy.driverName = this.driverName;
        copy.mobileNo = this.mobileNo;
        copy.departureLocation = this.departureLocation;
        copy.departureDateTime = this.departureDateTime;
        copy.consignmentNo = this.consignmentNo;
        return copy;
    }
}

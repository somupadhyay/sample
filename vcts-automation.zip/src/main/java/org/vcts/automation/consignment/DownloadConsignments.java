package org.vcts.automation.consignment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.vcts.automation.core.TestCore;
import org.vcts.automation.login.VCTSLoginForm;
import org.vcts.automation.login.VCTSLogin;

import java.io.IOException;
import java.util.*;

public class DownloadConsignments extends TestCore {

    private final String loginUrl = "https://vctsdri.dri.gov.np/login";
    private final String consignmentDownloadUrl = "https://vctsdri.dri.gov.np/consignment/consignment_print/";

    private Map<String, List<ConsignmentDetail>> docDB = null;
    private String username;
    private String password;
    public DownloadConsignments(String username, String password)  {
        this.username = username;
        this.password = password;
        try {
            init();
        }catch (Exception ex){
            System.err.println("Error running the application please.");
            System.exit(1);
        }
    }
    public void init() throws IOException {
        initTestSuite();
        initWebDriver();
    }

    public void close(){
        tearDown();
    }

    public Map<String, List<ConsignmentDetail>> downloadConsigment(List<String> consignmentIds){
        if(null == consignmentIds || consignmentIds.isEmpty()){
            System.err.println("No consignment to download exiting ... ");
            return Collections.emptyMap();
        }
        try {
            login();
            docDB = new HashMap<>();
            for (String id : consignmentIds) {
                if(null != id && id.trim().length()>1) {
                    driver.get(consignmentDownloadUrl + id);
                    List<WebElement> cds1 = driver.findElements(By.className("table-responsive"));
                    int i = 0;
                    ConsignmentDetail common = new ConsignmentDetail();
                    common.setConsignmentNo(id);
                    for (WebElement ele : cds1) {
                       // System.out.println(" \n --- > " + i + " \n");
                       // System.out.println(ele.getText());
                        if (i == 1) {
                            parseHeader2(ele, id, common);
                        }
                        i++;
                    }
                    //Body parsed.
                    WebElement cds = driver.findElement(By.className("consignment_documents"));
                    parseConsignmentDocuments(cds, id, common);
                    //header2 parse
                }

            }
        }finally {
            close();
        }
        return null == docDB ? Collections.emptyMap(): docDB;
    }

    private void parseHeader2(WebElement webElement, String id, ConsignmentDetail doc) {
        List<WebElement> trs = webElement.findElements(By.tagName("tr"));
        WebElement secondEle = trs.get(1);
        List<WebElement> columns = secondEle.findElements(By.tagName("td"));
        int i = 41;
        List<ConsignmentDetail> docs = new ArrayList<>();
        doc.setConsignmentNo(id);
        /*
        if(docDB.containsKey(id)){
            docs = docDB.get(id);
            docs.stream().forEach(doc1 -> doc1.setConsignmentNo(id));
        }else{
            docDB.put(id,new ArrayList<>());
        }

         */
        for(WebElement el: columns){
            doc.add(el.getText(),i);
            i++;
        }
        System.out.println("common : " + doc);
        //docDB.get(id).add(doc);

    }

    private void parseConsignmentDocuments(WebElement element, String id, ConsignmentDetail common){
        WebElement body = element.findElement(By.tagName("tbody"));
        //System.out.println("-----> body <------");
        List<WebElement> tr = body.findElements(By.tagName("tr"));
        for(WebElement row: tr){
            System.out.println("print each row.");
            System.out.println(row.getText());
            parseEachRow(row,id, common.copy());
        }/*
        List<WebElement> bodyc = body.findElements(By.tagName("td"));
        ConsignmentDetail doc = new ConsignmentDetail();
        doc.setConsignmentNo(id);
        List<ConsignmentDetail> docs = new ArrayList<>();
        if(docDB.containsKey(id)){
            docs = docDB.get(id);
            docs.stream().forEach(doc1 -> doc1.setConsignmentNo(id));
        }else{
            docDB.put(id,new ArrayList<>());
        }
        doc.setConsignmentNo(id);
        int i = 1;
        for(WebElement el: bodyc){
            doc.add(el.getText(),i);
            i++;
        }
        docDB.get(id).add(doc);*/
        System.out.println("Test -> ");
        System.out.println("abcd \n"+body.getText());
        System.out.println("abcd end");
        //System.out.println(" ----> doc \n "+doc);

    }

    public void parseEachRow(WebElement row, String id, ConsignmentDetail doc){
        List<WebElement> bodyc = row.findElements(By.tagName("td"));
        doc.setConsignmentNo(id);
        List<ConsignmentDetail> docs = new ArrayList<>();
        if(docDB.containsKey(id)){
            docs = docDB.get(id);
            docs.stream().forEach(doc1 -> doc1.setConsignmentNo(id));
        }else{
            docDB.put(id,new ArrayList<>());
        }
        doc.setConsignmentNo(id);
        int i = 1;
        for(WebElement el: bodyc){
            doc.add(el.getText(),i);
            i++;
        }
        docDB.get(id).add(doc);
        System.out.println("Row Parsing -> ");
        System.out.println(id + " = "+row.getText());
        System.out.println("Row end");
    }
    private void parse(List<WebElement> elements){
        if(null == elements || elements.isEmpty()){
            return;
        }

        for(WebElement element: elements){
            System.out.println(element.getText());
        }
    }
    private void login(){
        VCTSLogin loginPage = openLoginPage();
        VCTSLoginForm form = loginPage.getLoginForm();
        form.username(username);
        form.password(password);
        form.submit();
        System.out.println("logged in as: "+username);
    }

    public VCTSLogin openLoginPage()  {
        driver.get(loginUrl);
        return new VCTSLogin(driver);
    }
}

package org.vcts.automation;


import org.apache.commons.cli.*;

public class AutomationRunner {

    private String inputFile;

    public static void main(String[] args) {
        AutomationRunner runner = null;
        try {
            runner = new AutomationRunner(args);
        } catch (ParseException e) {
            throw new RuntimeException("तपाईंले प्रविष्ट गर्नुभएको इनपुट सही छैन !");
        }
        runner.run();
    }

    private AutomationRunner(){}

    public AutomationRunner(String[] args) throws ParseException {
        Options options = new Options();
        options.addOption("in", "input-file", true, "Input text file full path");

        HelpFormatter formatter = new HelpFormatter();
        CommandLineParser parser = new DefaultParser();

        CommandLine cmd = parser.parse(options,args);
        Option[] rOptions = cmd.getOptions();

        for(int i=0; i<rOptions.length;i++){
            System.out.println(rOptions[i].getOpt() +" - "+rOptions[i].getValue());
            System.out.println();
        }

        if(cmd.hasOption("in")){
            this.inputFile = cmd.getOptionValue("in");
        }else{
            System.out.println("Missing input (.txt) file, Please include and re-run!");
            formatter.printHelp("AutomationRunner",options);
            System.exit(0);
        }

        System.out.println("Starting to download the consignment list detail for input file "+ inputFile);
    }

    public void run(){
        DownloadConsignmentMain downloadConsignmentMain = new DownloadConsignmentMain(this.inputFile);
        downloadConsignmentMain.run();
    }

}
package org.vcts.automation.listeners;

import io.qameta.allure.Allure;
import lombok.extern.slf4j.Slf4j;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;
import org.vcts.automation.core.TestCore;

/**
 * @author Somnath on 02.01.2023
 */
@Slf4j
public final class TestListener extends TestListenerAdapter {

    private final ScreenShooter screenShooter = ScreenShooter.getInstance();

    @Override
    public void onTestFailure(final ITestResult tr) {
        log.error("---- TEST FAILED ----", tr.getThrowable());
        screenShooter.addFullPageScreenshotToReport(tr.getInstance());
        Allure.addAttachment("Console Logs", collectBrowserConsoleLogs(tr.getInstance()));
    }

    @Override
    public void onTestSuccess(final ITestResult tr) {
        log.info("---- TEST PASSED -----");
    }

    private String collectBrowserConsoleLogs(final Object currentClass) {
        StringBuilder builder = new StringBuilder();
        WebDriver driver = ((TestCore) currentClass).getDriver();
        LogEntries logEntries = driver.manage().logs().get(LogType.BROWSER);
        for (LogEntry logEntry : logEntries) {
            builder.append(logEntry.getMessage());
            builder.append("\n=============================================\n");
        }
        return builder.toString();
    }

}

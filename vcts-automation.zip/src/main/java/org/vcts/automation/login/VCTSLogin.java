package org.vcts.automation.login;

import static org.openqa.selenium.support.ui.ExpectedConditions.visibilityOf;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.vcts.automation.web.WebPage;
import org.vcts.automation.login.VCTSLoginForm;

public class VCTSLogin extends WebPage{

	@FindBy(name = "login_form")
	private WebElement loginForm;
	 
	public VCTSLogin(WebDriver driver) {
		super(driver);
        wait.until(visibilityOf(loginForm));
	}

	public VCTSLoginForm getLoginForm() {
		return new VCTSLoginForm(driver, this.loginForm);
	}
	
}

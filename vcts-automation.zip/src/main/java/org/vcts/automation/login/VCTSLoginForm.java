package org.vcts.automation.login;

import static org.openqa.selenium.support.ui.ExpectedConditions.visibilityOf;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.vcts.automation.web.WebComponent;

import io.qameta.allure.Step;

public class VCTSLoginForm extends WebComponent {

		private final WebElement parent;
	
	 	@FindBy(name = "login_form")
	    private WebElement loginForm;

	    @FindBy(name = "identity")
	    private WebElement identity;

	    @FindBy(name = "password")
	    private WebElement pwd;

	    @FindBy(name = "submit")
	    private WebElement submitButton;
	    
	    private static final String congsignmentPrintUrl = "https://vctsdri.dri.gov.np/consignment/consignment_print/";
	    
	public VCTSLoginForm(WebDriver driver, WebElement parent) {
		super(driver, parent);
		// TODO Auto-generated constructor stub
		this.parent = parent;
	}

	@Step
    public void username(final String username) {
        identity.sendKeys(Keys.CONTROL + "A" + Keys.BACK_SPACE);
        identity.sendKeys(username);
    }
	
	@Step
    public void password(final String password) {
		pwd.sendKeys(Keys.CONTROL + "A" + Keys.BACK_SPACE);
		pwd.sendKeys(password);
    }
	
	@Step
    public void submit() {
		wait.until(visibilityOf(submitButton)).click();
    }

	public WebDriver getDriver(){
		return driver;
	}
}

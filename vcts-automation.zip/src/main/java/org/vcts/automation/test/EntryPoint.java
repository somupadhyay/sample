package org.vcts.automation.test;

import java.io.IOException;

import org.vcts.automation.login.VCTSLoginForm;
import org.vcts.automation.login.VCTSLogin;

public class EntryPoint {

	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		LoginTest test = new LoginTest();
		test.init();
		VCTSLogin loginPage = test.openLoginPage();
		VCTSLoginForm form = loginPage.getLoginForm();
		form.username("6140984641");
		form.password("Bandd@vcts");
		form.submit();
		test.close();
	}

}

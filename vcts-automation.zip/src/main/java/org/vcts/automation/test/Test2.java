package org.vcts.automation.test;

import org.vcts.automation.consignment.ConsignmentDetail;
import org.vcts.automation.consignment.DownloadConsignments;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class Test2 {

    //private static final String fileName = "C:\\Users\\somnath\\Downloads\\srijusamiksasuppliers.txt";
    //private static final String fileName = "C:\\Users\\somnath\\Downloads\\minadeviekikritkrishifarm.txt";

    //private static final String fileName = "C:\\Users\\somnath\\Downloads\\banddekikritkrishifarm.txt";
    private static final String fileName = "C:\\Users\\somnath\\Downloads\\test.txt";
    public static void main(String[] args) {

        List<String> allLines = readFile();
        if(allLines.isEmpty() || allLines.size()<3){
            System.err.println("nothing to download");
            System.exit(0);
        }
        String username = getUserName(allLines);
        String password = getPassword(allLines);
        List<String>  consigmentIds = getConsigmentId(allLines);
        allLines = null;
        DownloadConsignments dc = new DownloadConsignments(username, password);
        Map<String, List<ConsignmentDetail>> docDB = dc.downloadConsigment(consigmentIds);
        writeToFile(docDB);
    }

    private static List<String> getConsigmentId(List<String> allLines) {
        int i=0;
        List<String> ids = new ArrayList<>();
        for(String id: allLines){
            if(i>1){
               ids.add(id.trim());
            }
            i++;
        }
        return ids;
    }

    private static String getPassword(List<String> allLines) {
        return allLines.get(1).trim();
    }

    private static String getUserName(List<String> allLines) {
        return allLines.get(0).trim();
    }

    public static final List<String> readFile(){
        List<String> allLines = null;
        try {
            allLines = Files.readAllLines(Paths.get(fileName));

            for (String line : allLines) {
                System.out.println(line);
            }
        } catch ( IOException e) {
            e.printStackTrace();
        }
        return  allLines == null ? Collections.emptyList(): allLines;
    }

    public static void writeToFile(Map<String, List<ConsignmentDetail>> docDB){
       String outFile = fileName+"-"+System.currentTimeMillis()+".csv";
        List<ConsignmentDetail> consignmentDetailList = new ArrayList<>();
        docDB.forEach((k,v) -> consignmentDetailList.addAll(v));
       String contents = ConsignmentDetail.toCSV(consignmentDetailList);

        System.out.println("\n");
       System.out.println(contents);
        try {

            // write to file
            Files.write(Paths.get(outFile), contents.getBytes());

        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}

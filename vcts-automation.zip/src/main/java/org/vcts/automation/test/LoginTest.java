package org.vcts.automation.test;

import java.io.IOException;

import org.vcts.automation.browser.BrowserLocalStorage;
import org.vcts.automation.core.TestCore;
import org.vcts.automation.login.VCTSLogin;

import io.qameta.allure.Step;

public class LoginTest extends TestCore {

	private final String loginUrl = "https://vctsdri.dri.gov.np/login";
	
	public void init() throws IOException{
		initTestSuite();
		initWebDriver();
	}
	
	public void close() throws IOException{
		System.out.println("closing...");
		tearDown();
	}
	@Step
    public VCTSLogin openLoginPage()  {
        driver.get(loginUrl);
        return new VCTSLogin(driver);
    }

    @Step
    public void clearLocalStorage() {
        new BrowserLocalStorage(driver).clear();
    }
    
    
}

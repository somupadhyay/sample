package org.vcts.automation.web.components;

import lombok.Getter;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.vcts.automation.web.WebComponent;

import java.util.List;

import static java.util.stream.Collectors.toList;

/**
 * @author Somnath on 02.01.2023
 */
public final class TodoList extends WebComponent {

    @Getter
    private final List<TodoRow> todoRows;

    @FindBy(css = "li.todo")
    private List<WebElement> rows;

    public TodoList(final WebDriver driver, final WebElement parent) {
        super(driver, parent);
        todoRows = mapTodoRows();
    }

    private List<TodoRow> mapTodoRows() {
        return rows.stream().map(row -> new TodoRow(driver, row)).collect(toList());
    }

}

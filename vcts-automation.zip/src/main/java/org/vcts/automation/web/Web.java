package org.vcts.automation.web;

import lombok.AccessLevel;
import lombok.Getter;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.vcts.automation.core.Constants;

/**
 * @author Somnath on 02.01.2023
 */
abstract class Web {

    @Getter(AccessLevel.PROTECTED)
    private static final int TIMEOUT = Constants.WAIT_TIMEOUT;
    protected final WebDriver driver;
    protected final WebDriverWait wait;
    protected final Actions actions;

    Web(final WebDriver driver) {
        this.driver = driver;
        actions = new Actions(driver);
        wait = new WebDriverWait(driver, TIMEOUT);
    }

}

package org.vcts.automation.web;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;

/**
 * @author Somnath on 02.01.2023
 */
public abstract class WebPage extends Web {

    public WebPage(final WebDriver driver) {
        super(driver);
        initWebElements();
    }

    private void initWebElements() {
        final ElementLocatorFactory factory = new AjaxElementLocatorFactory(driver, getTIMEOUT());
        PageFactory.initElements(factory, this);
    }

}
